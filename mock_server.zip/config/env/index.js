'use strict';

module.exports = {
  //是否初始化数据
  seedDB: process.env.INITDATA || false
};
